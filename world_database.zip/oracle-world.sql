

--
-- Table structure for table `cities`
--

BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE WWS_CITIES';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE WWS_CITIES (
  ID number(7) check (id > 0) NOT NULL,
  NAME varchar2(255) NOT NULL,
  STATE_ID number(7) check (STATE_ID > 0) NOT NULL,
  STATE_CODE varchar2(255) NOT NULL,
  COUNTRY_ID number(7) check (COUNTRY_ID > 0) NOT NULL,
  COUNTRY_CODE char(2) NOT NULL,
  LATITUDE number(10,8) NOT NULL,
  LONGITUDE number(11,8) NOT NULL,
  CREATED_AT timestamp(0) DEFAULT TO_TIMESTAMP('2013-12-31 19:31:01','YYYY-MM-DD HH24:MI:SS') NOT NULL,
  UPDATED_AT timestamp(0) DEFAULT SYSTIMESTAMP NOT NULL,
  FLAG number(3) DEFAULT '1' NOT NULL,
  WIKIDATAID varchar2(255) DEFAULT NULL
)  ;

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE WWS_COUNTRIES';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE WWS_COUNTRIES (
  ID number(7) check (id > 0) NOT NULL,
  NAME varchar2(100) NOT NULL,
  ISO3 char(3) DEFAULT NULL,
  ISO2 char(2) DEFAULT NULL,
  PHONECODE varchar2(255) DEFAULT NULL,
  CAPITAL varchar2(255) DEFAULT NULL,
  CURRENCY varchar2(255) DEFAULT NULL,
  CREATED_AT timestamp(0) DEFAULT NULL NULL,
  UPDATED_AT timestamp(0) DEFAULT SYSTIMESTAMP NOT NULL,
  FLAG number(3) DEFAULT '1' NOT NULL,
  WIKIDATAID varchar2(255) DEFAULT NULL
) ;

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE WWS_STATES';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE WWS_STATES (
  ID number(7) check (id > 0) NOT NULL,
  NAME varchar2(255) NOT NULL,
  COUNTRY_ID number(7) check (COUNTRY_ID > 0) NOT NULL,
  COUNTRY_CODE char(2) NOT NULL,
  FIPS_CODE varchar2(255) DEFAULT NULL,
  ISO2 varchar2(255) DEFAULT NULL,
  CREATED_AT timestamp(0) DEFAULT NULL NULL,
  UPDATED_AT timestamp(0) DEFAULT SYSTIMESTAMP NOT NULL,
  FLAG number(3) DEFAULT '1' NOT NULL,
  WIKIDATAID varchar2(255) DEFAULT NULL
)  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cities`
--
ALTER TABLE WWS_CITIES
  ADD CONSTRAINT CITY_PK PRIMARY KEY (ID);

CREATE INDEX WWS_CITIES_STATE ON WWS_CITIES (STATE_ID);
CREATE INDEX WWS_CITIES_COUNTRY ON WWS_CITIES (COUNTRY_ID);

--
-- Indexes for table `countries`
--
ALTER TABLE WWS_COUNTRIES
  ADD CONSTRAINT WWS_COUNTRY_PK PRIMARY KEY (ID);

--
-- Indexes for table `states`
--
ALTER TABLE WWS_STATES
  ADD CONSTRAINT WWS_STATE_PK PRIMARY KEY (ID);

CREATE INDEX WWS_COUNTRY_STATE ON WWS_STATES (COUNTRY_ID),

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cities`
--
--ALTER TABLE WWS_CITIES
--  MODIFY ID mediumint(8) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `countries`
--
--ALTER TABLE WWS_COUNTRIES
--  MODIFY ID mediumint(8) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `states`
--
--ALTER TABLE WWS_STATES
--  MODIFY ID mediumint(8) unsigned NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `cities`
--
ALTER TABLE WWS_CITIES
  ADD CONSTRAINT REL_WWS_CITIES_WWS_STATE FOREIGN KEY (STATE_ID) REFERENCES WWS_STATES (ID);
ALTER TABLE WWS_CITIES
  ADD CONSTRAINT REL_WWS_CITIES_WWS_COUNTRY FOREIGN KEY (COUNTRY_ID) REFERENCES WWS_COUNTRIES (ID);

--
-- Constraints for table `states`
--
ALTER TABLE WWS_STATES
  ADD CONSTRAINT REL_WWS_COUNTRY_WWS_STATE FOREIGN KEY (COUNTRY_ID) REFERENCES WWS_COUNTRIES (ID);
